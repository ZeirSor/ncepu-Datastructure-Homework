#pragma once
#include "header.h"
#include "query.h"

int querying();