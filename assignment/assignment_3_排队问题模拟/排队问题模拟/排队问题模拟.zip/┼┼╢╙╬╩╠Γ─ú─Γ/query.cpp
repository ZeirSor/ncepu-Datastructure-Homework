#include "query.h"
#include "header.h"
constexpr auto MAXQSIZE = 20;		//ÿ�����������10��;

int InitQueue(SqQueue* Q)				//ѭ�����г�ʼ��
{
	(*Q).base = (TimeData*)malloc(sizeof(TimeData) * MAXQSIZE);
	if (!(*Q).base)
		exit(0);
	(*Q).front = 0;
	(*Q).rear = 0;
	return 1;
}

int QueueLength(SqQueue Q)				//ѭ�����г���
{
	return (Q.rear - Q.front + MAXQSIZE) % MAXQSIZE;
}

int GetShortestQueue(SqQueue* Q)
{
	int min = 20;
	int i;
	for (i = 0; i < 3; i++)
	{
		if (QueueLength(Q[i]) < min)
			min = QueueLength(Q[i]);
	}
	return i;
}

int EnQueue(SqQueue* Q, TimeData e)		//ѭ���������
{
	if ((Q->rear + 1) % MAXQSIZE == Q->front)
		return 0;
	Q->base[Q->rear] = e;
	Q->rear = (Q->rear + 1) % MAXQSIZE;
	return 1;
}

int IsEmpty(SqQueue Q)					//�ж϶���Ϊ��
{
	if (Q.front == Q.rear)
		return 1;
	else
		return 0;
}

int LeaveQueue(SqQueue* q, int i)
// TODO: �����߼�
{
	SqQueue* CLeaTime = &(q[q->front]);
	int sum = 0;
	int Window = i + 1;
	int upStart;
	int wait;
	int start = 0;
	int leave = 0;
	int leave1 = 0;
	int wait1 = 0;
	int serve = 0;
	int AriTime = 0;
	int LeaTime = 0;
	int Start = 0;
	if (CLeaTime->base->Leave <= NowTime)
	{
		start = CLeaTime->base->Arrive;
		AriTime = OpenTime + start;

		leave = CLeaTime->base->Leave;
		leave = OpenTime + leave1;

		wait = CLeaTime->base->Wait;
		serve = CLeaTime->base->Serve;

		upStart = CLeaTime->base->Start;
		serve = OpenTime + upStart;

		printf("\t%-15d%-15d%-15d%-15d%-15d%-15d%-15d\n", j, Window, start, AriTime, wait1, serve, LeaTime);
		TotalWaitTime = TotalWaitTime + wait;
		if (IsEmpty(*q))
		{
			return 0;
		}
		if (q->front == q->rear)
		{
			q->front = q->rear == NULL;
			return 1;
		}
		CLeaTime = &(q[q->front]);
		q->front = (q->front + 1) % MAXQSIZE;
		return 1;
	}
	return 0;
}