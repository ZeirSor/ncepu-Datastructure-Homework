#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <Windows.h>

constexpr auto ERROR = 0;
constexpr auto OK = 1;
